// script.js

function handleSubmit(e) {
  e.preventDefault();
  alert("Your inquiry has been submitted successfully! We'll get back to you soon.");
}
